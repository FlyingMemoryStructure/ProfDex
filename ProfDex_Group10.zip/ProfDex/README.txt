Step 1: Connect to to the mongodb database, with mongod in the command line.

Step 2: Open up mongodb compass and import the provided JSON files to their appropriate collections, the names of the JSON files should aid in assigning the file to the collection. First import the connection using the Profdex.json to setup such, then import each json file for the data respective to the collections.

Step 3: Unzip the ProfDex zip file and assign the directory to it. 

Step 4: Run the program through npm start and go to http://localhost:3000/ in your browser to view and navigate through the webpage.

Note: For navigation of the web application, after the proper setup of the database, please refer to the attached video for reference.